const somar = require('./sum');

console.log('Somar:', somar(10, 20));